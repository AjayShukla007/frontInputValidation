import { useState } from "react";
import Alert from "@mui/material/Alert";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Snackbar from "@mui/material/Snackbar";
import Typography from "@mui/material/Typography";
import logo from "../../assets/logo.svg";

import * as EmailValidator from "email-validator";

export default function LoginForm() {
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState(false);
  const [validatePass, setValidatePass] = useState(false);
  const [validateMail, setValidateMail] = useState(false);

  const validateForm = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = data.get("email");
    const password = data.get("password");
    // Add validation code here
    const validateEmail = EmailValidator.validate(email);
    const regLowercase = /^(?=.*[a-z])/;
    const regUppercase = /^(?=.*[A-Z])/;
    const regDigit = /^(?=.*\d)/;
    const regSpecialChar = /^(?=.*[@$!%*?&])/;

    if (!validateEmail) {
      setShowAlert(true);
      setAlertMessage("please enter valid email");
      setValidateMail(true);
    } else if (validateEmail) {
      setValidateMail(false);
    }

    if (password.length < 8) {
      setShowAlert(true);
      setAlertMessage("Password must be at least 8 characters long");
      setValidatePass(true);
    } else if (!regLowercase.test(password)) {
      setShowAlert(true);
      setAlertMessage("Password must contain at least one lowercase character");
      setValidatePass(true);
    } else if (!regUppercase.test(password)) {
      setShowAlert(true);
      setAlertMessage("Password must contain at least one uppercase character");
      setValidatePass(true);
    } else if (!regDigit.test(password)) {
      setShowAlert(true);
      setAlertMessage("Password must contain at least one digit");
      setValidatePass(true);
    } else if (!regSpecialChar.test(password)) {
      setShowAlert(true);
      setAlertMessage("Password should contain at least one special character");
      setValidatePass(true);
    } else {
      setValidatePass(false);
      setAlertMessage("Login successfull");
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log({
      email: data.get("email"),
      password: data.get("password"),
    });
    validateForm(event);
    setShowAlert(true);
  };

  return (
    <>
      {showAlert && (
        <Snackbar
          open={showAlert}
          autoHideDuration={6000}
          onClose={() => setShowAlert(false)}
          message={alertMessage}
        >
          <Alert>{alertMessage}</Alert>
        </Snackbar>
      )}
      <Grid
        item
        xs={false}
        sm={4}
        md={7}
        sx={{
          backgroundImage: "url(https://source.unsplash.com/random)",
          backgroundRepeat: "no-repeat",
          backgroundColor: (t) =>
            t.palette.mode === "light"
              ? t.palette.grey[50]
              : t.palette.grey[900],
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
        <Box
          sx={{
            my: 8,
            mx: 4,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Box
            sx={{
              my: 2,
            }}
          >
            <img src={logo} width="147" alt="harrison.ai" />
          </Box>
          <Typography component="h1" variant="h5">
            Sign in
          </Typography>
          <Box
            component="form"
            noValidate
            onSubmit={handleSubmit}
            sx={{ mt: 1 }}
          >
            <TextField
              error={validateMail}
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
            />
            <TextField
              error={validatePass}
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign In
            </Button>
          </Box>
        </Box>
      </Grid>
    </>
  );
}
