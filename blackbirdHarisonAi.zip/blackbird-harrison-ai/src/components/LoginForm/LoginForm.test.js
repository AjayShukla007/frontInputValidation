import { render, screen, fireEvent } from '@testing-library/react';
import LoginForm from '.';

test('renders sign in page', () => {
  render(<LoginForm />);
  const signInText = screen.getByText("Sign in");
  expect(signInText).toBeInTheDocument();
});

test('displays error message for invalid email', () => {
  render(<LoginForm />);
  const emailInput = screen.getByLabelText('Email Address');
  const submitButton = screen.getByText('Sign In');

  fireEvent.change(emailInput, { target: { value: 'invalid_email' } });
  fireEvent.click(submitButton);

  const errorMessage = screen.getByText('please enter a valid email');
  expect(errorMessage).toBeInTheDocument();
});

test('displays error message for invalid password', () => {
  render(<LoginForm />);
  const passwordInput = screen.getByLabelText('Password');
  const submitButton = screen.getByText('Sign In');

  fireEvent.change(passwordInput, { target: { value: 'short' } });
  fireEvent.click(submitButton);

  const errorMessage = screen.getByText('Password must be at least 8 characters long');
  expect(errorMessage).toBeInTheDocument();
});

test('displays success message for valid email and password', () => {
  render(<LoginForm />);
  const emailInput = screen.getByLabelText('Email Address');
  const passwordInput = screen.getByLabelText('Password');
  const submitButton = screen.getByText('Sign In');

  fireEvent.change(emailInput, { target: { value: 'valid@example.com' } });
  fireEvent.change(passwordInput, { target: { value: 'Strong@Password1' } });
  fireEvent.click(submitButton);

  const successMessage = screen.getByText('Login successful');
  expect(successMessage).toBeInTheDocument();
});